
let cart = [];

function addToCart(item, price) {
  cart.push({item, price});
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById('cart-items');
  cartList.innerHTML = '';
  cart.forEach(c => {
    const li = document.createElement('li');
    li.textContent = `${c.item} - ${c.price}`;
    cartList.appendChild(li);
  });
}

function checkout() {
  if(cart.length === 0) {
    alert('Keranjang Anda kosong!');
  } else {
    alert('Terima kasih! Pesanan Anda sedang diproses.');
    cart = [];
    updateCart();
  }
}

let slideIndex = 0;
showSlides();

function showSlides() {
  let slides = document.getElementsByClassName("slide");
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  slides[slideIndex-1].style.display = "block";  
  setTimeout(showSlides, 3000); // Change image every 3 seconds
}
